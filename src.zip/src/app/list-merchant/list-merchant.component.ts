import { Component, OnInit } from '@angular/core';
import{Merchant,MyserviceService}from '../myservice.service';
@Component({
  selector: 'app-list-merchant',
  templateUrl: './list-merchant.component.html',
  styleUrls: ['./list-merchant.component.css']
})
export class ListMerchantComponent implements OnInit {
service:MyserviceService;
  constructor(service:MyserviceService) {
    this.service=service;
    }
    
    merchants:Merchant[]=[]//creating employees object for Employee Array 
    ngOnInit() {
    // this.service.fetchMerchants(); 
    // this. merchants=this.service.getMerchants();
    }

}
