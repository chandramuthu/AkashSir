import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-merchant-login',
  templateUrl: './merchant-login.component.html',
  styleUrls: ['./merchant-login.component.css']
})
export class MerchantLoginComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
