import { Injectable } from '@angular/core';
import{HttpClient}from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class MyserviceService {
  url: string = "http://localhost:9123/merchant";
  constructor(private http: HttpClient) {
  }
  private handleError(error: any): Promise<any> {
    return Promise.reject(error.error || error);
  }
  
  
 
//  addMerchant(m:Merchant){
//   this.merchants.push(m);
  
// }

    

// fetched:boolean=false;
// fetchMerchants(){
// this.http.get('./assets/merchant.json')
//  .subscribe(
// data=>{
// if(!this.fetched)
//  {
// this.convert(data);
// this.fetched=true;
//  }
//  }
//  );
// }

//   getMerchants():Merchant[]{
    
  
// return this.merchants;
// }
// convert(data1:any){
// for(let o of data1)
//  {
// let m=new Merchant(o.merchantId,o.merchantAnswer,o.merchantCompanyName,o.merchantContactNo,o.merchantDiscount,o.merchantGSTNo,o.merchantName,o.merchantPassword,o.merchantQuestion,o.merchantStatus);
// this.merchants.push(m);
//  }

addMerchant(merchant): Promise<any> {
  return this.http.post(this.url + '/add', merchant)
    .toPromise()
    .then(response => response)
    .catch(this.handleError);
    
}

}

export class Merchant{
  merchantId:number;
  merchantAnswer:string;
  merchantCompanyName:string;
  merchantContactNo:string;
  merchantDiscount:number;
  merchantGSTNo:string;
  merchantName:string;
  merchantPassword:string;
  merchantQuestion:number;
  merchantStatus:number;

    
        constructor(  merchantId:number,merchantAnswer:string,merchantCompanyName:string,merchantContactNo:string,merchantDiscount:number,merchantGSTNo:string,merchantName:string,merchantPassword:string, merchantQuestion:number,merchantStatus:number)
        {
          this.merchantId=merchantId;
          this.merchantAnswer=merchantAnswer;
          this.merchantCompanyName=merchantCompanyName;
          this.merchantContactNo=merchantContactNo;
          this.merchantDiscount=merchantDiscount;
          this.merchantGSTNo=merchantGSTNo;
          this.merchantName=merchantName;
          this.merchantPassword=merchantPassword;
          this.merchantQuestion=merchantQuestion;
          this.merchantStatus=merchantStatus;
        }
      }