import { Component, OnInit } from '@angular/core';
import { Merchant,MyserviceService } from '../myservice.service';
import{Router}from '@angular/router'
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

 
  router:Router;
 createdFlag:boolean=false;
 service:MyserviceService;
 constructor(service:MyserviceService, router:Router) {this.service=service; 
this.router=router
}
 
 ngOnInit() {
 }
 addMerchant(data:any) {
  let merchant = new Merchant(data.merchantId,data.merchantAnswer,data.merchantCompanyName,data.merchantContactNo,data.merchantDiscount,data.merchantGSTNo,data.merchantName,data.merchantPassword,data.merchantQuestion,data.merchantStatus);
  this.service.addMerchant(merchant).then(response => {
    if(response.success == true)
    {
      alert("Merchant added successfully, Merchant id is "+response.result.merchantId);
    }
  }
    , err => {
      if (err.success != undefined && err.success == false) {
        alert(err.errors);
      }
    });

//  this.createdMerchant=new Merchant(data. merchantId,data.merchantAnswer,data.merchantCompanyName,data.merchantContactNo,data.merchantDiscount,data.merchantGSTNo,data.merchantName,data.merchantPassword,data.merchantQuestion,data.merchantStatus)
// this.service.addMerchant(this.createdMerchant);
// this.router.navigateByUrl('display-merchants');


}
}