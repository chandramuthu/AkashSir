package com.cap.service;

import java.util.List;
import org.springframework.stereotype.Service;


import com.cap.entities.Merchant;
import com.cap.entities.Product;


@Service

public interface MerchantService  {
	public Merchant addMerchant(Merchant merchant);

	public List<Product> addProduct(Product product);
	
	

}
