package com.cap.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cap.dao.MerchantRepo;
import com.cap.dao.ProductRepo;

import com.cap.entities.Merchant;
import com.cap.entities.Product;


@Service
public class MerchantServiceImpl implements MerchantService{
	@Autowired
	MerchantRepo repo;
	@Autowired
	ProductRepo repo1;

	@Override
	public Merchant addMerchant(Merchant merchant) {
		repo.save(merchant);
		return merchant;
	}

	@Override
	public List<Product> addProduct(Product product) {
		repo1.save(product);
		return repo1.findAll();
	}

	


}
