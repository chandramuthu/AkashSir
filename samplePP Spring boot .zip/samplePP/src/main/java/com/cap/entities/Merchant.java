package com.cap.entities;



import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name="merch")
public class Merchant  {
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "merchant_seq_gen")
	@SequenceGenerator(name = "merchant_seq_gen", initialValue = 1000, sequenceName = "merchant_seq_gen")
	@Column
	private int merchant_Id;
	@Column
	private String Name;
	@Column
	private String Email;
	@Column
    private String Password;
	
	@Column/*(unique=true)
	@NotNull*/
	private String ConfirmPassword;
	@Column
	private String PhoneNumber;
	@Column
	private String CompanyName;
	@Column
	private int Discount;
	@Column
	private String AadharNumber;
	public int getMerchant_Id() {
		return merchant_Id;
	}
	public void setMerchant_Id(int merchant_Id) {
		this.merchant_Id = merchant_Id;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	public String getPassword() {
		return Password;
	}
	public void setPassword(String password) {
		Password = password;
	}
	public String getConfirmPassword() {
		return ConfirmPassword;
	}
	public void setConfirmPassword(String confirmPassword) {
		ConfirmPassword = confirmPassword;
	}
	public String getPhoneNumber() {
		return PhoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		PhoneNumber = phoneNumber;
	}
	public String getCompanyName() {
		return CompanyName;
	}
	public void setCompanyName(String companyName) {
		CompanyName = companyName;
	}
	public int getDiscount() {
		return Discount;
	}
	public void setDiscount(int discount) {
		Discount = discount;
	}
	public String getAadharNumber() {
		return AadharNumber;
	}
	public void setAadharNumber(String aadharNumber) {
		AadharNumber = aadharNumber;
	}
	
	public Merchant() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public String toString() {
		return "Merchant [merchant_Id=" + merchant_Id + ", Name=" + Name + ", Email=" + Email + ", Password=" + Password
				+ ", ConfirmPassword=" + ConfirmPassword + ", PhoneNumber=" + PhoneNumber + ", CompanyName="
				+ CompanyName + ", Discount=" + Discount + ", AadharNumber=" + AadharNumber + "]";
	}
	
	public Merchant(int merchant_Id, String name, String email, String password, String confirmPassword,
			String phoneNumber, String companyName, int discount, String aadharNumber) {
		super();
		this.merchant_Id = merchant_Id;
		Name = name;
		Email = email;
		Password = password;
		ConfirmPassword = confirmPassword;
		PhoneNumber = phoneNumber;
		CompanyName = companyName;
		Discount = discount;
		AadharNumber = aadharNumber;
	}
	
	
	
}
